<?php if(session('success') || $errors->any()): ?>
    <div class="p-4 mb-4 rounded-md <?php echo e(session('success') ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'); ?>">
        <?php if(session('success')): ?>
            <div class="flex items-center justify-between">
                <strong><?php echo e(session('success')); ?></strong>
                <button type="button" class="text-green-700" onclick="this.parentElement.parentElement.remove();">x</button>
            </div>
        <?php endif; ?>

        <?php if($errors->any()): ?>
            <div>
                <strong><?php echo e(__('Please fix the following errors:')); ?></strong>
                <ul class="mt-2 list-disc list-inside">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
    </div>
<?php endif; ?>
<?php /**PATH H:\laragon\www\dada-ltd\resources\views/components/alert.blade.php ENDPATH**/ ?>