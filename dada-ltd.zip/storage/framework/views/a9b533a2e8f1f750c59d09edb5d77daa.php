<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Production Details')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8 space-y-6">
            <div class="p-4 sm:p-8 bg-white shadow sm:rounded-lg">
                <section class="mb-6">
                    <header class="flex items-center justify-between">
                        <div>
                            <h2 class="text-lg font-bold text-gray-900">
                                <?php echo e(__('Production Information')); ?>

                            </h2>
                            <p class="mt-1 text-sm text-gray-600">
                                <?php echo e(__("Detailed information about the production.")); ?>

                            </p>
                        </div>

                        <a href="<?php echo e(route('production.index')); ?>" class="inline-flex items-center px-3 py-1 text-gray-700 bg-gray-200 border border-transparent rounded-md text-xs font-bold hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                            Back to Productions List
                        </a>
                    </header>
                </section>

                <section>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Image</h3>
                             <?php if($production->image): ?>
                                <img src="<?php echo e(asset('storage/' . $production->image)); ?>" alt="Production Image" class="h-16 w-16 object-cover rounded-md" />
                            <?php else: ?>
                                No Image
                            <?php endif; ?>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">PS</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->ps); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">PS Date</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->ps_date); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">SST10</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->sst10); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Buyer PO</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->buyer_po); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Buyer</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->buyer); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">SD Date</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->sd_date); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Quantity</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->qty); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Cap Item</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->cap_item); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Ship Via</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->ship_via); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Destination</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->dest); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Final Destination</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->final_dest); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">EMBO</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->embo); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Washing</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->washing); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Color Pattern</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->c_pattern); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Visor Pattern</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->v_pattern); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Color Cutter</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->c_cutter); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Visor Cutter</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->v_cutter); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Eyelet Number</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->eyelet_number); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Eyelet Color</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->eyelet_color); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Eyelet Position</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->eyelet_position); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Visor 6</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->visor_6); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Visor 1.5</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->visor_1_5); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Visor 0.5</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->visor_0_5); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Front Mold</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->f_mold); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Back Mold</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->b_mold); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Extra Stitch</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->extra_stitch); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Packing</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->packing); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Row</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->row); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">CM from Front End</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->cm_from_front_end); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Created At</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->created_at); ?></p>
                        </div>

                        <div>
                            <h3 class="text-sm font-bold text-gray-700">Updated At</h3>
                            <p class="mt-1 text-gray-900"><?php echo e($production->updated_at); ?></p>
                        </div>
                    </div>
                </section>

                <section class="mt-6">
                    <a href="<?php echo e(route('production.edit', $production->id)); ?>" class="inline-flex items-center px-3 py-1 text-gray-700 bg-gray-200 border border-transparent rounded-md text-xs font-bold hover:bg-gray-300 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500">
                        Edit Production
                    </a>
                </section>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH H:\laragon\www\dada-ltd\resources\views/production/show.blade.php ENDPATH**/ ?>